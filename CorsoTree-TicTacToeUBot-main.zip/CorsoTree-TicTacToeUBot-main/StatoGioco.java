public enum StatoGioco {
    INCORSO, TERMINATO;
}
