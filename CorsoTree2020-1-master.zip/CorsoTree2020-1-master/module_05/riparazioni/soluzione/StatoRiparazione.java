public enum StatoRiparazione {
    inAttesa, inCorso, terminata
}
