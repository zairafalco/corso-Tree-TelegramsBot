public enum StatoTecnico {
    DISPONIBILE, RIPARAZIONE, FERIE
}
