## Ferrovia 🛴 

Progettare un sistema ferroviario, fatto di treni e binari

Un treno ha
* un codice
* la velocità attuale
* una numero massimo di vagoni
* lo stato delle porte dei vagoni (aperte, chiuse o guaste)
* numero passeggeri a bordo
* numeroMassimo passeggeri

e può fare le seguenti operazioni
* partire, che aumenta la velocità oltre lo zero
* frenare, che porta la velocità a zero
* entrare in stazione, che ferma il treno
* far salire o scendere un passeggero
* aprire e chiudere le porte dei vagoni

Esistono due tipi di treno
* Treno Regionale
  * che ha un massimo di 15 vagoni
  
* FrecciaRossa
  * ha un massimo di 20 vagoni

