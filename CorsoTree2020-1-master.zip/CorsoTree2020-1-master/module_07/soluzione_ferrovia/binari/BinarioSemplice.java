package binari;

public class BinarioSemplice extends Binario {

    public BinarioSemplice(Binario successivo) {
        super(successivo);
    }

}
