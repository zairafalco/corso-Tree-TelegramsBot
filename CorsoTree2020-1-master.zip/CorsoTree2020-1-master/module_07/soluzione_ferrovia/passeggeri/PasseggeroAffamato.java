package passeggeri;

public class PasseggeroAffamato extends Passeggero {

    public PasseggeroAffamato(String nome, String codiceBiglietto, int idVagone, int idStazioneArrivo) {
        super(nome, codiceBiglietto, idVagone, idStazioneArrivo);
    }

}
