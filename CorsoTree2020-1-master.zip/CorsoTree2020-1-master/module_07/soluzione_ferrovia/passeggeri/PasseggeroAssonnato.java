package passeggeri;

public class PasseggeroAssonnato extends Passeggero {

    public PasseggeroAssonnato(String nome, String codiceBiglietto, int idVagone, int idStazioneArrivo) {
        super(nome, codiceBiglietto, idVagone, idStazioneArrivo);
    }

}
