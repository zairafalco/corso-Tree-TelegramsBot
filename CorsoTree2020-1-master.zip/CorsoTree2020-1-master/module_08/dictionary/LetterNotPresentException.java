package module_08.dictionary;

public class LetterNotPresentException extends Exception{
}
