package module_08.dictionary;

public class WordNotPresentException extends Exception{
}
