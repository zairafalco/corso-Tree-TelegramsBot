package com.finalproject.treebackendroom1;

public enum Gender {
    MALE, FEMALE, OTHER
}
