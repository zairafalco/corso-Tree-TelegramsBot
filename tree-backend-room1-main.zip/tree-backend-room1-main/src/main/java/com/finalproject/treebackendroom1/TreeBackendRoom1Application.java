package com.finalproject.treebackendroom1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TreeBackendRoom1Application {

	public static void main(String[] args) {
		SpringApplication.run(TreeBackendRoom1Application.class, args);
	}

}
