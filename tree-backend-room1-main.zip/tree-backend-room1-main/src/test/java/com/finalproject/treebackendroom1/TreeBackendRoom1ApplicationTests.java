package com.finalproject.treebackendroom1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TreeBackendRoom1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
